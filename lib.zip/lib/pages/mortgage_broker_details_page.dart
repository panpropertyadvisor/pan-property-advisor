import 'dart:io';
import 'package:flutter/material.dart';
import 'package:file_selector/file_selector.dart';
import 'mortgage_broker_preview_page.dart';

class MortgageBrokerDetailsPage extends StatefulWidget {
  const MortgageBrokerDetailsPage({super.key});

  @override
  State<MortgageBrokerDetailsPage> createState() =>
      _MortgageBrokerDetailsPageState();
}

class _MortgageBrokerDetailsPageState extends State<MortgageBrokerDetailsPage> {
  // SECTION VISIBILITY
  bool _showSection2 = false;
  bool _showSection3 = false;

  // ERROR MESSAGE
  String _errorMessage = "";

  // IMAGE FILES
  File? _profilePhoto;
  File? _companyLogo;

  // TRACK TOUCHED FIELDS
  final Map<String, bool> _touched = {};

  // SCROLL WARNING FLAGS
  bool _scrollWarnSection1 = false;
  bool _scrollWarnSection2 = false;

  // -----------------------------
  // CONTROLLERS
  // -----------------------------
  final _fullNameController = TextEditingController();
  final _companyNameController = TextEditingController();
  final _experienceController = TextEditingController();

  final _creditLicenceController = TextEditingController();
  final _afcaController = TextEditingController();

  final _shortBioController = TextEditingController();
  final _fullBioController = TextEditingController();
  final _differenceController = TextEditingController();
  final _awardsController = TextEditingController();
  final _testimonialsController = TextEditingController();

  final _emailController = TextEditingController();
  final _mobileController = TextEditingController();
  final _availabilityController = TextEditingController();

  final _linkedinController = TextEditingController();
  final _googleReviewsController = TextEditingController();
  final _websiteController = TextEditingController();

  // CONTACT VISIBILITY TOGGLES
  bool _showEmailToCustomers = true;
  bool _showMobileToCustomers = true;

  // DROPDOWNS & TOGGLES
  String? _selectedAggregator;
  bool _onlineAppointments = false;

  // -----------------------------
  // FLOATING MESSAGE
  // -----------------------------
  void _showFloatingMessage(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        behavior: SnackBarBehavior.floating,
        backgroundColor: Colors.redAccent,
        duration: const Duration(seconds: 2),
      ),
    );
  }

  // -----------------------------
  // VALIDATION LOGIC
  // -----------------------------
  bool _validateName(String text) {
    if (text.trim().length < 3) return false;
    if (RegExp(r'[^a-zA-Z0-9 ]').hasMatch(text)) return false;
    return true;
  }

  bool _validateExperience(String text) {
    if (text.isEmpty) return false;
    if (!RegExp(r'^[0-9]+$').hasMatch(text)) return false;
    return true;
  }

  bool _validateEmail(String text) {
    return text.contains("@") && text.contains(".com");
  }

  bool _validateMobile(String text) {
    if (!RegExp(r'^[0-9]+$').hasMatch(text)) return false;
    if (text.length < 10) return false;
    return true;
  }

  bool _validateSection1() {
    return _validateName(_fullNameController.text) &&
        _validateName(_companyNameController.text) &&
        _validateExperience(_experienceController.text);
  }

  bool _validateSection2() {
    return _creditLicenceController.text.trim().isNotEmpty &&
        _afcaController.text.trim().isNotEmpty &&
        _selectedAggregator != null; 
        
  }

  bool _validateContactVisibility() {
    return _showEmailToCustomers || _showMobileToCustomers;
  }

  bool _validateAll() {
    return _validateSection1() &&
        _validateSection2() &&
        _shortBioController.text.trim().isNotEmpty &&
        _validateEmail(_emailController.text) &&
        _validateMobile(_mobileController.text) &&
        _validateContactVisibility();
  }

  // -----------------------------
  // IMAGE PICKER (file_selector)
  // -----------------------------
  Future<void> _pickImage(bool isProfilePhoto) async {
    final XTypeGroup typeGroup = XTypeGroup(
      label: 'images',
      extensions: ['jpg', 'jpeg', 'png'],
    );

    final XFile? file = await openFile(acceptedTypeGroups: [typeGroup]);

    if (file != null) {
      setState(() {
        if (isProfilePhoto) {
          _profilePhoto = File(file.path);
        } else {
          _companyLogo = File(file.path);
        }
      });
    }
  }

  // -----------------------------
  // SAVE → PREVIEW
  // -----------------------------
  void _attemptSave() {
    if (!_validateAll()) {
      if (!_validateContactVisibility()) {
        _showFloatingMessage(
            "At least one contact method should be made available.");
      } else {
        _showFloatingMessage("Please complete all mandatory fields.");
      }
      setState(() {
        _errorMessage = "Please complete mandatory fields";
      });
      return;
    }

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => MortgageBrokerPreviewPage(
          fullName: _fullNameController.text,
          title: "",
          companyName: _companyNameController.text,
          experience: _experienceController.text,
          shortBio: _shortBioController.text,
          fullBio: _fullBioController.text,
          difference: _differenceController.text,
          awards: _awardsController.text,
          testimonials: _testimonialsController.text,
          email: _emailController.text,
          mobile: _mobileController.text,
          officeAddress: "",
          serviceAreas: "",
          linkedin: _linkedinController.text,
          googleReviews: _googleReviewsController.text,
          website: _websiteController.text,
        ),
      ),
    );
  }

  // -----------------------------
  // UI
  // -----------------------------
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Mortgage Broker Details")),
      body: SafeArea(
        child: NotificationListener<ScrollNotification>(
          onNotification: (scroll) {
            if (!_scrollWarnSection1 && !_validateSection1()) {
              _scrollWarnSection1 = true;
              _showFloatingMessage(
                  "Please complete all mandatory fields to continue.");
            } else if (_showSection2 &&
                !_scrollWarnSection2 &&
                !_validateSection2()) {
              _scrollWarnSection2 = true;
              _showFloatingMessage(
                  "Please complete all mandatory fields to continue.");
            }
            return false;
          },
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (_errorMessage.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 12),
                    child: Text(
                      _errorMessage,
                      style: const TextStyle(color: Colors.red, fontSize: 16),
                    ),
                  ),

                // -------------------------
                // SECTION 1
                // -------------------------
                sectionTitle("1. Personal & Professional Identity"),

                mandatoryNameField("Full Name *", _fullNameController, () {
                  setState(() {
                    _showSection2 = _validateSection1();
                  });
                }),

                mandatoryNameField("Company Name *", _companyNameController, () {
                  setState(() {
                    _showSection2 = _validateSection1();
                  });
                }),

                mandatoryExperienceField(
                    "Years of Experience *", _experienceController, () {
                  setState(() {
                    _showSection2 = _validateSection1();
                  });
                }),

                imageUpload("Profile Photo", _profilePhoto, () {
                  _pickImage(true);
                }),

                imageUpload("Company Logo", _companyLogo, () {
                  _pickImage(false);
                }),

                // -------------------------
                // SECTION 2
                // -------------------------
                if (_showSection2) ...[
                  const SizedBox(height: 24),
                  sectionTitle("2. Licensing & Compliance"),

                  mandatoryField("Credit Licence Number (ACL/CRN) *",
                      _creditLicenceController, () {
                    setState(() {
                      _showSection3 = _validateSection2();
                    });
                  }),

                  mandatoryField("AFCA Membership Number *", _afcaController,
                      () {
                    setState(() {
                      _showSection3 = _validateSection2();
                    });
                  }),

                  dropdownField(
                    "Aggregator Name *",
                    ["PLAN", "AFG", "Connective", "Loan Market", "Other"],
                    _selectedAggregator,
                    (value) {
                      setState(() {
                        _selectedAggregator = value;
                        _showSection3 = _validateSection2();
                      });
                    },
                  ),
                ],

                // -------------------------
                // SECTION 3
                // -------------------------
                if (_showSection3) ...[
                  const SizedBox(height: 24),
                  sectionTitle("3. About / Bio"),

                  mandatoryField("Short Bio *", _shortBioController, () {}),

                  longField("Full Bio / Story", _fullBioController),
                  longField("What Makes You Different?", _differenceController),
                  longField("Awards & Recognition", _awardsController),
                  longField("Customer Testimonials", _testimonialsController),

                  const SizedBox(height: 24),
                  sectionTitle("4. Contact & Availability"),

                  mandatoryEmailField("Email Address *", _emailController, () {
                    setState(() {});
                  }),

                  SwitchListTile(
                    title: const Text("Do you want customers to see your email?"),
                    value: _showEmailToCustomers,
                    onChanged: (v) {
                      setState(() => _showEmailToCustomers = v);
                    },
                  ),

                  mandatoryMobileField("Mobile Number *", _mobileController, () {
                    setState(() {});
                  }),

                  SwitchListTile(
                    title: const Text(
                        "Do you want customers to see your contact number?"),
                    value: _showMobileToCustomers,
                    onChanged: (v) {
                      setState(() => _showMobileToCustomers = v);
                    },
                  ),

                  if (!_validateContactVisibility())
                    const Padding(
                      padding: EdgeInsets.only(bottom: 12),
                      child: Text(
                        "At least one contact method should be made available",
                        style: TextStyle(color: Colors.red),
                      ),
                    ),

                  normalField("Availability Hours", _availabilityController),

                  SwitchListTile(
                    title: const Text("Online Appointments Available"),
                    value: _onlineAppointments,
                    onChanged: (v) {
                      setState(() => _onlineAppointments = v);
                    },
                  ),

                  const SizedBox(height: 40),

                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: _attemptSave,
                      child: const Text("Save & Preview"),
                    ),
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }

  // -----------------------------
  // UI HELPERS
  // -----------------------------

  Widget sectionTitle(String title) => Padding(
        padding: const EdgeInsets.only(bottom: 12),
        child: Text(
          title,
          style: const TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
      );

  // NAME FIELD WITH SPECIAL VALIDATION
  Widget mandatoryNameField(
      String label, TextEditingController controller, VoidCallback onChanged) {
    final String text = controller.text.trim();
    final bool touched = _touched[label] ?? false;

    String? errorMessage;
    if (touched) {
      if (text.isEmpty) {
        errorMessage = "This field is required";
      } else if (text.length < 3) {
        errorMessage = "Must be at least 3 characters";
      } else if (RegExp(r'[^a-zA-Z0-9 ]').hasMatch(text)) {
        errorMessage = "Special characters are not allowed";
      }
    }

    final bool showRed = touched && errorMessage != null;

    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: TextField(
        controller: controller,
        onChanged: (value) {
          _touched[label] = true;
          onChanged();
          setState(() {});
        },
        decoration: InputDecoration(
          labelText: label,
          errorText: errorMessage,
          labelStyle: TextStyle(
            color: showRed ? Colors.red : Colors.black,
          ),
          border: OutlineInputBorder(
            borderSide: BorderSide(
              color: showRed ? Colors.red : Colors.grey,
            ),
          ),
          enabledBorder: OutlineInputBorder(
            borderSide: BorderSide(
              color: showRed ? Colors.red : Colors.grey,
            ),
          ),
          focusedBorder: OutlineInputBorder(
            borderSide: BorderSide(
              color: showRed ? Colors.red : Colors.blue,
              width: 2,
            ),
          ),
        ),
      ),
    );
  }

  // EXPERIENCE FIELD (NUMERIC ONLY)
  Widget mandatoryExperienceField(
      String label, TextEditingController controller, VoidCallback onChanged) {
    final String text = controller.text.trim();
    final bool touched = _touched[label] ?? false;

    String? errorMessage;
    if (touched) {
      if (text.isEmpty) {
        errorMessage = "This field is required";
      } else if (!RegExp(r'^[0-9]+$').hasMatch(text)) {
        errorMessage = "Only numbers allowed";
      }
    }

    final bool showRed = touched && errorMessage != null;

    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: TextField(
        controller: controller,
        keyboardType: TextInputType.number,
        onChanged: (value) {
          _touched[label] = true;
          onChanged();
          setState(() {});
        },
        decoration: InputDecoration(
          labelText: label,
          errorText: errorMessage,
          labelStyle: TextStyle(
            color: showRed ? Colors.red : Colors.black,
          ),
          border: OutlineInputBorder(
            borderSide: BorderSide(
              color: showRed ? Colors.red : Colors.grey,
            ),
          ),
          enabledBorder: OutlineInputBorder(
            borderSide: BorderSide(
              color: showRed ? Colors.red : Colors.grey,
            ),
          ),
          focusedBorder: OutlineInputBorder(
            borderSide: BorderSide(
              color: showRed ? Colors.red : Colors.blue,
              width: 2,
            ),
          ),
        ),
      ),
    );
  }

  // EMAIL FIELD VALIDATION
  Widget mandatoryEmailField(
      String label, TextEditingController controller, VoidCallback onChanged) {
    final String text = controller.text.trim();
    final bool touched = _touched[label] ?? false;

    String? errorMessage;
    if (touched) {
      if (text.isEmpty) {
        errorMessage = "This field is required";
      } else if (!text.contains("@") || !text.contains(".com")) {
        errorMessage = "Enter a valid email address";
      }
    }

    final bool showRed = touched && errorMessage != null;

    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: TextField(
        controller: controller,
        onChanged: (value) {
          _touched[label] = true;
          onChanged();
          setState(() {});
        },
        decoration: InputDecoration(
          labelText: label,
          errorText: errorMessage,
          labelStyle: TextStyle(
            color: showRed ? Colors.red : Colors.black,
          ),
          border: OutlineInputBorder(
            borderSide: BorderSide(
              color: showRed ? Colors.red : Colors.grey,
            ),
          ),
          enabledBorder: OutlineInputBorder(
            borderSide: BorderSide(
              color: showRed ? Colors.red : Colors.grey,
            ),
          ),
          focusedBorder: OutlineInputBorder(
            borderSide: BorderSide(
              color: showRed ? Colors.red : Colors.blue,
              width: 2,
            ),
          ),
        ),
      ),
    );
  }

  // MOBILE FIELD VALIDATION
  Widget mandatoryMobileField(
      String label, TextEditingController controller, VoidCallback onChanged) {
    final String text = controller.text.trim();
    final bool touched = _touched[label] ?? false;

    String? errorMessage;
    if (touched) {
      if (text.isEmpty) {
        errorMessage = "This field is required";
      } else if (!RegExp(r'^[0-9]+$').hasMatch(text)) {
        errorMessage = "Only numbers allowed";
      } else if (text.length < 10) {
        errorMessage = "Must be at least 10 digits";
      }
    }

    final bool showRed = touched && errorMessage != null;

    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: TextField(
        controller: controller,
        keyboardType: TextInputType.number,
        onChanged: (value) {
          _touched[label] = true;
          onChanged();
          setState(() {});
        },
        decoration: InputDecoration(
          labelText: label,
          errorText: errorMessage,
          labelStyle: TextStyle(
            color: showRed ? Colors.red : Colors.black,
          ),
          border: OutlineInputBorder(
            borderSide: BorderSide(
              color: showRed ? Colors.red : Colors.grey,
            ),
          ),
          enabledBorder: OutlineInputBorder(
            borderSide: BorderSide(
              color: showRed ? Colors.red : Colors.grey,
            ),
          ),
          focusedBorder: OutlineInputBorder(
            borderSide: BorderSide(
              color: showRed ? Colors.red : Colors.blue,
              width: 2,
            ),
          ),
        ),
      ),
    );
  }

  // GENERIC MANDATORY FIELD
  Widget mandatoryField(
      String label, TextEditingController controller, VoidCallback onChanged) {
    final bool isEmpty = controller.text.trim().isEmpty;
    final bool touched = _touched[label] ?? false;
    final bool showRed = touched && isEmpty;

    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: TextField(
        controller: controller,
        onChanged: (value) {
          _touched[label] = true;
          onChanged();
          setState(() {});
        },
        decoration: InputDecoration(
          labelText: label,
          errorText: touched && isEmpty ? "This field is required" : null,
          labelStyle: TextStyle(
            color: showRed ? Colors.red : Colors.black,
          ),
          border: OutlineInputBorder(
            borderSide: BorderSide(
              color: showRed ? Colors.red : Colors.grey,
            ),
          ),
          enabledBorder: OutlineInputBorder(
            borderSide: BorderSide(
              color: showRed ? Colors.red : Colors.grey,
            ),
          ),
          focusedBorder: OutlineInputBorder(
            borderSide: BorderSide(
              color: showRed ? Colors.red : Colors.blue,
              width: 2,
            ),
          ),
        ),
      ),
    );
  }

  Widget normalField(String label, TextEditingController controller) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: TextField(
        controller: controller,
        decoration: InputDecoration(
          labelText: label,
          border: const OutlineInputBorder(),
        ),
      ),
    );
  }

  Widget longField(String label, TextEditingController controller) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: TextField(
        controller: controller,
        maxLines: 5,
        decoration: InputDecoration(
          labelText: label,
          border: const OutlineInputBorder(),
        ),
      ),
    );
  }

  Widget dropdownField(
    String label,
    List<String> items,
    String? selected,
    Function(String?) onChanged,
  ) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: DropdownButtonFormField<String>(
        value: selected,
        decoration: InputDecoration(
          labelText: label,
          border: const OutlineInputBorder(),
        ),
        items: items
            .map((e) => DropdownMenuItem(
                  value: e,
                  child: Text(e),
                ))
            .toList(),
        onChanged: onChanged,
      ),
    );
  }

  Widget imageUpload(String label, File? file, VoidCallback onTap) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label),
          const SizedBox(height: 8),
          GestureDetector(
            onTap: onTap,
            child: Container(
              height: 140,
              width: double.infinity,
              decoration: BoxDecoration(
                border: Border.all(color: Colors.grey),
              ),
              child: file == null
                  ? const Center(child: Text("Tap to upload image"))
                  : Image.file(file, fit: BoxFit.cover),
            ),
          ),
        ],
      ),
    );
  }
}
