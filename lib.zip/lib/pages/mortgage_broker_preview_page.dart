import 'package:flutter/material.dart';

class MortgageBrokerPreviewPage extends StatelessWidget {
  final String fullName;
  final String title;
  final String companyName;
  final String experience;
  final String shortBio;
  final String fullBio;
  final String difference;
  final String awards;
  final String testimonials;
  final String email;
  final String mobile;
  final String officeAddress;
  final String serviceAreas;
  final String linkedin;
  final String googleReviews;
  final String website;

  const MortgageBrokerPreviewPage({
    super.key,
    required this.fullName,
    required this.title,
    required this.companyName,
    required this.experience,
    required this.shortBio,
    required this.fullBio,
    required this.difference,
    required this.awards,
    required this.testimonials,
    required this.email,
    required this.mobile,
    required this.officeAddress,
    required this.serviceAreas,
    required this.linkedin,
    required this.googleReviews,
    required this.website,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Preview")),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [

            // -------------------------
            // HEADER
            // -------------------------
            Text(
              fullName,
              style: const TextStyle(
                fontSize: 26,
                fontWeight: FontWeight.bold,
              ),
            ),

            if (title.isNotEmpty)
              Padding(
                padding: const EdgeInsets.only(top: 4),
                child: Text(
                  title,
                  style: const TextStyle(
                    fontSize: 16,
                    color: Colors.grey,
                  ),
                ),
              ),

            const SizedBox(height: 16),

            // -------------------------
            // SHORT BIO
            // -------------------------
            sectionTitle("Short Bio"),
            sectionText(shortBio),

            const SizedBox(height: 16),

            // -------------------------
            // PROFESSIONAL DETAILS
            // -------------------------
            sectionTitle("Professional Details"),
            sectionText("Company: $companyName"),
            sectionText("Experience: $experience years"),

            const SizedBox(height: 16),

            // -------------------------
            // FULL BIO
            // -------------------------
            if (fullBio.isNotEmpty) ...[
              sectionTitle("Full Bio"),
              sectionText(fullBio),
              const SizedBox(height: 16),
            ],

            // -------------------------
            // DIFFERENTIATORS
            // -------------------------
            if (difference.isNotEmpty) ...[
              sectionTitle("What Makes You Different"),
              sectionText(difference),
              const SizedBox(height: 16),
            ],

            // -------------------------
            // AWARDS
            // -------------------------
            if (awards.isNotEmpty) ...[
              sectionTitle("Awards & Recognition"),
              sectionText(awards),
              const SizedBox(height: 16),
            ],

            // -------------------------
            // TESTIMONIALS
            // -------------------------
            if (testimonials.isNotEmpty) ...[
              sectionTitle("Customer Testimonials"),
              sectionText(testimonials),
              const SizedBox(height: 16),
            ],

            // -------------------------
            // CONTACT
            // -------------------------
            sectionTitle("Contact"),
            sectionText("Email: $email"),
            sectionText("Mobile: $mobile"),

            if (officeAddress.isNotEmpty)
              sectionText("Office: $officeAddress"),

            if (serviceAreas.isNotEmpty)
              sectionText("Service Areas: $serviceAreas"),

            const SizedBox(height: 16),

            // -------------------------
            // SOCIAL LINKS
            // -------------------------
            sectionTitle("Social Profiles"),

            if (linkedin.isNotEmpty)
              sectionText("LinkedIn: $linkedin"),

            if (googleReviews.isNotEmpty)
              sectionText("Google Reviews: $googleReviews"),

            if (website.isNotEmpty)
              sectionText("Website: $website"),

            const SizedBox(height: 32),

            // -------------------------
            // SUBMIT BUTTON
            // -------------------------
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () {
                  // TODO: Save to Firestore
                  Navigator.pop(context);
                },
                child: const Text("Submit"),
              ),
            ),

            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }

  // -------------------------
  // UI HELPERS
  // -------------------------
  Widget sectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: Text(
        title,
        style: const TextStyle(
          fontSize: 18,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }

  Widget sectionText(String text) {
    return Padding(
      padding: const EdgeInsets.only(top: 4),
      child: Text(
        text,
        style: const TextStyle(fontSize: 15),
      ),
    );
  }
}
