import 'package:flutter/material.dart';

class InvestorTermsPage extends StatefulWidget {
  const InvestorTermsPage({super.key});

  @override
  State<InvestorTermsPage> createState() => _InvestorTermsPageState();
}

class _InvestorTermsPageState extends State<InvestorTermsPage> {
  bool _accepted = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Investor Terms & Conditions"),
        backgroundColor: Colors.black,
        foregroundColor: Color(0xFFFFD700),
      ),

      // FIX: Use SafeArea + Column + Expanded + Footer
      body: SafeArea(
        child: Column(
          children: [
            // Scrollable content
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(16),
                child: const Text(
                  '''
1. Purpose of Service
PAN Property Advisor provides general property information, financial estimations, and investment tools. This service does not constitute financial, legal, or taxation advice.

2. No Financial Advice
All insights are general in nature. Investors should seek independent professional advice before making financial decisions.

3. Accuracy of Information
While reasonable efforts are made to ensure accuracy, PAN Property Advisor does not guarantee completeness or suitability of any information.

4. Investor Responsibilities
You acknowledge that you are solely responsible for your investment decisions and will independently verify all calculations.

5. Subscription Fees
By proceeding, you agree to a monthly subscription fee of AUD 4.99, billed automatically until cancelled.

6. Refunds
Subscription fees are non-refundable except where required under Australian Consumer Law.

7. Limitation of Liability
PAN Property Advisor is not liable for financial loss, investment outcomes, or decisions made based on app content.

8. Privacy & Data Use
Your personal information will be handled in accordance with our Privacy Policy.

9. Acceptance
By selecting "I Agree", you confirm acceptance of these Terms & Conditions and the AUD 4.99 monthly subscription.
                  ''',
                  style: TextStyle(fontSize: 15, height: 1.4),
                ),
              ),
            ),

            // FIX: Footer stays ABOVE home bar
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  // Checkbox + label
                  Row(
                    children: [
                      Checkbox(
                        value: _accepted,
                        onChanged: (value) {
                          setState(() {
                            _accepted = value ?? false;
                          });
                        },
                      ),
                      const Text(
                        "I Agree",
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),

                  // Continue button
                  ElevatedButton(
                    onPressed: _accepted
                        ? () {
                            Navigator.pushNamed(context, '/investorAboutYou');
                          }
                        : null,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: _accepted ? Colors.black : Colors.grey[900],
                      foregroundColor: const Color(0xFFFFD700),   // gold text
                      disabledForegroundColor: Colors.grey,        // optional
                      disabledBackgroundColor: Colors.grey[800],   // optional
                      padding: const EdgeInsets.symmetric(
                        horizontal: 20,
                        vertical: 12,
                      ),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                        side: BorderSide(
                          color: _accepted ? const Color(0xFFFFD700) : Colors.grey,
                          width: 1.5,
                        ),
                      ),
                    ),
                    child: const Text(
                      "Continue",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                        color: Color(0xFFFFD700),   // ← ensures gold text ALWAYS
                      ),
                    ),
                  )

                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
