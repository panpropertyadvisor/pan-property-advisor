import 'package:flutter/material.dart';

class BuyersAgentPreviewPage extends StatelessWidget {
  final String fullName;
  final String title;
  final String companyName;
  final String experience;

  final String shortBio;
  final String fullBio;
  final String difference;
  final String awards;
  final String testimonials;

  final String email;
  final String mobile;
  final String officeAddress;
  final String serviceAreas;

  final String linkedin;
  final String googleReviews;
  final String website;

  const BuyersAgentPreviewPage({
    super.key,
    required this.fullName,
    required this.title,
    required this.companyName,
    required this.experience,
    required this.shortBio,
    required this.fullBio,
    required this.difference,
    required this.awards,
    required this.testimonials,
    required this.email,
    required this.mobile,
    required this.officeAddress,
    required this.serviceAreas,
    required this.linkedin,
    required this.googleReviews,
    required this.website,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Buyers Agent Profile Preview'),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _section("Personal & Professional Identity", [
                _item("Full Name", fullName),
                _item("Title", title),
                _item("Company", companyName),
                _item("Years of Experience", experience),
              ]),

              _section("About / Bio", [
                _item("Short Bio", shortBio),
                _item("Full Bio", fullBio),
                _item("What Makes You Different", difference),
                _item("Awards & Recognition", awards),
                _item("Customer Testimonials", testimonials),
              ]),

              _section("Contact & Availability", [
                _item("Email", email),
                _item("Mobile", mobile),
                _item("Office Address", officeAddress),
                _item("Service Areas", serviceAreas),
              ]),

              _section("Online Presence", [
                _item("LinkedIn", linkedin),
                _item("Google Reviews", googleReviews),
                _item("Website", website),
              ]),

              const SizedBox(height: 24),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text("Back to Edit"),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _section(String title, List<Widget> children) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title,
              style: const TextStyle(
                  fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          ...children,
        ],
      ),
    );
  }

  Widget _item(String label, String value) {
    if (value.trim().isEmpty) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label,
              style: const TextStyle(
                  fontWeight: FontWeight.bold, fontSize: 14)),
          const SizedBox(height: 4),
          Text(value),
        ],
      ),
    );
  }
}
