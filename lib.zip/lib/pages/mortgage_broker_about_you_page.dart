import 'package:flutter/material.dart';
import 'package:flutter_application_1pan/services/api_service.dart';

class MortgageBrokerAboutYouPage extends StatefulWidget {
  const MortgageBrokerAboutYouPage({super.key});

  @override
  State<MortgageBrokerAboutYouPage> createState() =>
      _MortgageBrokerAboutYouPageState();
}

class _MortgageBrokerAboutYouPageState
    extends State<MortgageBrokerAboutYouPage> {
  final _formKey = GlobalKey<FormState>();

  // Profile fields controllers
  final _nameController = TextEditingController();
  final _emailController = TextEditingController();
  final _mobileController = TextEditingController();
  final _otpController = TextEditingController();

  // Payment controllers
  final _cardNameController = TextEditingController();
  final _cardNumberController = TextEditingController();
  final _expiryController = TextEditingController();
  final _cvvController = TextEditingController();

  bool _otpSent = false;
  bool _emailVerified = false;
  bool _canSendOtp = false;
  bool _otpValidLength = false;
  bool _saveEnabled = false;
  bool _sendingOtp = false;
  bool _showPaymentSection = false;

  String _statusMessage = "";

  @override
  void initState() {
    super.initState();
    _nameController.addListener(_updateSendOtpState);
    _emailController.addListener(_updateSendOtpState);
    _mobileController.addListener(_updateSendOtpState);
    _otpController.addListener(_checkOtpLength);
  }

  @override
  void dispose() {
    _nameController.dispose();
    _emailController.dispose();
    _mobileController.dispose();
    _otpController.dispose();
    _cardNameController.dispose();
    _cardNumberController.dispose();
    _expiryController.dispose();
    _cvvController.dispose();
    super.dispose();
  }

  bool _isNumeric(String s) {
    if (s.isEmpty) return false;
    return double.tryParse(s) != null;
  }

  void _updateSendOtpState() {
    final name = _nameController.text.trim();
    final email = _emailController.text.trim();
    final mobile = _mobileController.text.trim();
    final emailRegex = RegExp(r'^[^@]+@[^@]+\.[^@]+$');

    setState(() {
      _canSendOtp = name.isNotEmpty &&
          emailRegex.hasMatch(email) &&
          mobile.isNotEmpty &&
          mobile.length >= 8;
    });
  }

  void _checkOtpLength() {
    setState(() {
      _otpValidLength = _otpController.text.trim().length == 6;
    });
  }

  Future<void> _sendOtp() async {
    final email = _emailController.text.trim();

    setState(() {
      _sendingOtp = true;
      _otpSent = true;
      _statusMessage = "Sending OTP to your email...";
    });

    final success = await ApiService.sendOtp(email);

    if (!mounted) return;

    if (success) {
      setState(() {
        _sendingOtp = false;
        _statusMessage = "OTP sent to your email address";
      });
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('OTP sent to your email')),
      );
    } else {
      setState(() {
        _sendingOtp = false;
        _statusMessage = "Failed to send OTP";
      });
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Failed to send OTP')),
      );
    }
  }

  Future<void> _verifyOtp() async {
    final email = _emailController.text.trim();
    final otp = _otpController.text.trim();

    final success = await ApiService.verifyOtp(email, otp);

    if (!mounted) return;

    if (success) {
      setState(() {
        _emailVerified = true;
        _saveEnabled = true;
        _statusMessage = "OTP Verified, please save your details";
      });
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('OTP Verified')),
      );
    } else {
      setState(() {
        _statusMessage = "OTP is invalid. Enter correct OTP";
      });
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('OTP is invalid')),
      );
    }
  }

  Future<void> _processPayment() async {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text("Processing payment...")),
    );

    await Future.delayed(const Duration(seconds: 2));

    if (!mounted) return;

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text("Payment successful!")),
    );

    _navigateToNextStep();
  }

  void _navigateToNextStep() {
    Navigator.pushNamed(context, '/mortgageBrokerDetails');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('About You – Mortgage Broker')),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Tell us about you',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 16),

                // NAME
                TextFormField(
                  controller: _nameController,
                  decoration: const InputDecoration(
                    labelText: 'Name *',
                    border: OutlineInputBorder(),
                  ),
                  maxLength: 100,
                  validator: (value) {
                    if (value == null || value.trim().isEmpty) {
                      return 'Name is required';
                    }
                    if (!RegExp(r'^[a-zA-Z0-9 ]+$').hasMatch(value.trim())) {
                      return 'Only alphanumeric characters allowed';
                    }
                    return null;
                  },
                ),

                const SizedBox(height: 12),

                // EMAIL
                TextFormField(
                  controller: _emailController,
                  decoration: const InputDecoration(
                    labelText: 'Email address *',
                    border: OutlineInputBorder(),
                  ),
                  validator: (value) {
                    if (value == null || value.trim().isEmpty) {
                      return 'Email is required';
                    }
                    final email = value.trim();
                    final emailRegex = RegExp(r'^[^@]+@[^@]+\.[^@]+$');
                    if (!emailRegex.hasMatch(email)) {
                      return 'Please enter a valid email address';
                    }
                    return null;
                  },
                ),

                const SizedBox(height: 12),

                // MOBILE
                TextFormField(
                  controller: _mobileController,
                  decoration: const InputDecoration(
                    labelText: 'Mobile number *',
                    border: OutlineInputBorder(),
                  ),
                  keyboardType: TextInputType.number,
                  maxLength: 12,
                  validator: (value) {
                    if (value == null || value.trim().isEmpty) {
                      return 'Mobile number is required';
                    }
                    if (!_isNumeric(value.trim())) {
                      return 'Only numeric values allowed';
                    }
                    if (value.trim().length > 12) {
                      return 'Max 12 digits allowed';
                    }
                    return null;
                  },
                ),

                const SizedBox(height: 20),

                // OTP SECTION
                Row(
                  children: [
                    ElevatedButton(
                      onPressed: _canSendOtp ? _sendOtp : null,
                      child: Text(_otpSent ? 'Resend OTP' : 'Send OTP'),
                    ),
                    const SizedBox(width: 12),
                    if (_otpSent)
                      Expanded(
                        child: TextFormField(
                          controller: _otpController,
                          decoration: const InputDecoration(
                            labelText: 'Enter 6-digit OTP',
                          ),
                          keyboardType: TextInputType.number,
                          maxLength: 6,
                        ),
                      ),
                  ],
                ),

                const SizedBox(height: 12),

                if (_otpValidLength && _otpSent)
                  Center(
                    child: ElevatedButton(
                      onPressed: _verifyOtp,
                      child: const Text("Verify OTP"),
                    ),
                  ),

                if (_statusMessage.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(top: 12),
                    child: Row(
                      children: [
                        if (_sendingOtp)
                          const SizedBox(
                            width: 16,
                            height: 16,
                            child: CircularProgressIndicator(strokeWidth: 2),
                          ),
                        if (_sendingOtp) const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            _statusMessage,
                            style: TextStyle(
                              color: _emailVerified ? Colors.green : Colors.orange,
                              fontSize: 14,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),

                const SizedBox(height: 24),

                // SAVE BUTTON
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: _saveEnabled
                        ? () {
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(content: Text("Your profile has been saved")),
                            );
                            setState(() {
                              _showPaymentSection = true;
                            });
                          }
                        : null,
                    child: const Text('Save'),
                  ),
                ),

                // PAYMENT SECTION
                if (_showPaymentSection) ...[
                  const SizedBox(height: 24),
                  const Text(
                    "Payment – AUD 25",
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 12),

                  TextFormField(
                    controller: _cardNameController,
                    decoration: const InputDecoration(
                      labelText: 'Cardholder Name',
                      border: OutlineInputBorder(),
                    ),
                  ),

                  const SizedBox(height: 12),

                  TextFormField(
                    controller: _cardNumberController,
                    decoration: const InputDecoration(
                      labelText: 'Card Number',
                      border: OutlineInputBorder(),
                    ),
                    keyboardType: TextInputType.number,
                    maxLength: 16,
                  ),

                  const SizedBox(height: 12),

                  Row(
                    children: [
                      Expanded(
                        child: TextFormField(
                          controller: _expiryController,
                          decoration: const InputDecoration(
                            labelText: 'Expiry (MM/YY)',
                            border: OutlineInputBorder(),
                          ),
                          maxLength: 5,
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: TextFormField(
                          controller: _cvvController,
                          decoration: const InputDecoration(
                            labelText: 'CVV',
                            border: OutlineInputBorder(),
                          ),
                          keyboardType: TextInputType.number,
                          maxLength: 3,
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 24),

                  // ⭐ ORIGINAL PROCESS PAYMENT BUTTON
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: _processPayment,
                      child: const Text(
                        "Process Payment",
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ),

                  const SizedBox(height: 16),

                  // ⭐ NEW SKIP PAYMENT BUTTON (BLACK + GOLD)
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: _navigateToNextStep,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.black,
                        foregroundColor: const Color(0xFFFFD700),
                        padding: const EdgeInsets.symmetric(vertical: 16),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20),
                          side: const BorderSide(
                            color: Color(0xFFFFD700),
                            width: 1.5,
                          ),
                        ),
                        elevation: 6,
                        shadowColor: Colors.black.withAlpha(102),
                      ),
                      child: const Text(
                        "Skip Payment & Continue",
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w700,
                          letterSpacing: 1.1,
                        ),
                      ),
                    ),
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }
}
