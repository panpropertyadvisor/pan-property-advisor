import 'package:flutter/material.dart';
import '../utils/validators.dart';

// ⭐ NEW — using your backend API
import 'package:flutter_application_1pan/services/api_service.dart';

class InvestorAboutYouPage extends StatefulWidget {
  const InvestorAboutYouPage({super.key});

  @override
  State<InvestorAboutYouPage> createState() => _InvestorAboutYouPageState();
}

class _InvestorAboutYouPageState extends State<InvestorAboutYouPage> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _emailController = TextEditingController();
  final _mobileController = TextEditingController();
  final _otpController = TextEditingController();

  final _cardNumberController = TextEditingController();
  final _expiryController = TextEditingController();
  final _cvvController = TextEditingController();

  bool _otpSent = false;
  bool _emailVerified = false;
  bool _processingPayment = false;

  @override
  void dispose() {
    _nameController.dispose();
    _emailController.dispose();
    _mobileController.dispose();
    _otpController.dispose();
    _cardNumberController.dispose();
    _expiryController.dispose();
    _cvvController.dispose();
    super.dispose();
  }

  // ⭐ UPDATED — Send OTP using your backend API
  Future<void> _sendOtp() async {
    final email = _emailController.text.trim();

    if (!isValidEmail(email)) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter a valid email')),
      );
      return;
    }

    final success = await ApiService.sendOtp(email);

    if (success) {
      setState(() => _otpSent = true);

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('OTP sent to your email')),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Failed to send OTP')),
      );
    }
  }

  // ⭐ UPDATED — Verify OTP using backend (placeholder until backend route added)
  void _verifyOtp() async {
    final email = _emailController.text.trim();
    final otp = _otpController.text.trim();

    if (otp.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter the OTP')),
      );
      return;
    }

    // ⭐ Call your backend API
    final success = await ApiService.verifyOtp(email, otp);

    if (success) {
      setState(() => _emailVerified = true);

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Email verified successfully')),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Invalid or expired OTP')),
      );
    }
  }

  Future<void> _processPayment() async {
    if (!_emailVerified) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please verify your email first')),
      );
      return;
    }

    if (_cardNumberController.text.trim().isEmpty ||
        _expiryController.text.trim().isEmpty ||
        _cvvController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter billing details')),
      );
      return;
    }

    setState(() => _processingPayment = true);

    await Future.delayed(const Duration(seconds: 2));

    setState(() => _processingPayment = false);

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Payment processed (simulated).')),
    );

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => const _ServiceSelectionPage(),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Investor About You'),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Tell us about you',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 16),

                // NAME
                TextFormField(
                  controller: _nameController,
                  decoration: const InputDecoration(
                    labelText: 'Name *',
                    border: OutlineInputBorder(),
                  ),
                  maxLength: 100,
                  validator: (value) {
                    if (value == null || value.trim().isEmpty) {
                      return 'Name is required';
                    }
                    if (!isAlphaNumeric(value.trim())) {
                      return 'Only alphanumeric characters allowed';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 12),

                // EMAIL
                TextFormField(
                  controller: _emailController,
                  decoration: const InputDecoration(
                    labelText: 'Email address *',
                    border: OutlineInputBorder(),
                  ),
                  validator: (value) {
                    if (value == null || value.trim().isEmpty) {
                      return 'Email is required';
                    }
                    if (!isValidEmail(value.trim())) {
                      return 'Email must contain "@" and ".com"';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 12),

                // MOBILE
                TextFormField(
                  controller: _mobileController,
                  decoration: const InputDecoration(
                    labelText: 'Mobile number *',
                    border: OutlineInputBorder(),
                  ),
                  keyboardType: TextInputType.number,
                  maxLength: 12,
                  validator: (value) {
                    if (value == null || value.trim().isEmpty) {
                      return 'Mobile number is required';
                    }
                    if (!isNumeric(value.trim())) {
                      return 'Only numeric values allowed';
                    }
                    if (value.trim().length > 12) {
                      return 'Max 12 digits allowed';
                    }
                    return null;
                  },
                ),

                const SizedBox(height: 8),

                // ⭐ OTP SECTION
                Row(
                  children: [
                    ElevatedButton(
                      onPressed: _sendOtp,
                      child: const Text('Send OTP to email address'),
                    ),
                    const SizedBox(width: 8),

                    if (_otpSent)
                      Expanded(
                        child: TextFormField(
                          controller: _otpController,
                          decoration: const InputDecoration(
                            labelText: 'Enter 6-digit code',
                          ),
                          keyboardType: TextInputType.number,
                          maxLength: 6,
                        ),
                      ),

                    if (_otpSent)
                      IconButton(
                        onPressed: _verifyOtp,
                        icon: const Icon(Icons.check_circle, color: Colors.green),
                      ),
                  ],
                ),

                const SizedBox(height: 24),

                // BILLING SECTION
                const Text(
                  'Billing details',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 12),

                TextFormField(
                  controller: _cardNumberController,
                  decoration: const InputDecoration(
                    labelText: 'Credit/Debit card number',
                    border: OutlineInputBorder(),
                  ),
                  keyboardType: TextInputType.number,
                ),
                const SizedBox(height: 12),

                Row(
                  children: [
                    Expanded(
                      child: TextFormField(
                        controller: _expiryController,
                        decoration: const InputDecoration(
                          labelText: 'Expiry (MM/YY)',
                          border: OutlineInputBorder(),
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: TextFormField(
                        controller: _cvvController,
                        decoration: const InputDecoration(
                          labelText: 'Security code',
                          border: OutlineInputBorder(),
                        ),
                        keyboardType: TextInputType.number,
                      ),
                    ),
                  ],
                ),

                const SizedBox(height: 24),

                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: _processingPayment ? null : _processPayment,
                    child: _processingPayment
                        ? const CircularProgressIndicator(color: Colors.white)
                        : const Text('Process Payment'),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _ServiceSelectionPage extends StatelessWidget {
  const _ServiceSelectionPage();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('What do you need?'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: ListView(
          children: [
            const Text(
              'What do you need?',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 16),

            const Text(
              'Select mortgage broker',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            const Text('You can contact one mortgage broker.',
                style: TextStyle(color: Colors.black54)),
            const SizedBox(height: 8),

            DataTable(columns: const [
              DataColumn(label: Text('Name')),
              DataColumn(label: Text('Company')),
            ], rows: const [
              DataRow(cells: [
                DataCell(Text('Broker A')),
                DataCell(Text('ABC Finance')),
              ]),
              DataRow(cells: [
                DataCell(Text('Broker B')),
                DataCell(Text('XYZ Lending')),
              ]),
            ]),

            const SizedBox(height: 24),

            const Text(
              'Select buyers agent',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            const Text('You can contact one buyers agent.',
                style: TextStyle(color: Colors.black54)),
            const SizedBox(height: 8),

            DataTable(columns: const [
              DataColumn(label: Text('Name')),
              DataColumn(label: Text('Region')),
            ], rows: const [
              DataRow(cells: [
                DataCell(Text('Agent A')),
                DataCell(Text('Sydney')),
              ]),
              DataRow(cells: [
                DataCell(Text('Agent B')),
                DataCell(Text('Melbourne')),
              ]),
            ]),
          ],
        ),
      ),
    );
  }
}
