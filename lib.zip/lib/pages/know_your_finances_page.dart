import 'package:flutter/material.dart';
import '../utils/stamp_duty_calculator.dart';

class KnowYourFinancePage extends StatefulWidget {
  const KnowYourFinancePage({super.key});

  @override
  State<KnowYourFinancePage> createState() => _KnowYourFinancePageState();
}

class _KnowYourFinancePageState extends State<KnowYourFinancePage> {
  final _formKey = GlobalKey<FormState>();

  // Form fields
  String? propertyType;
  String? stateValue;
  String? lvrValue;

  final TextEditingController propertyValueController = TextEditingController();
  final TextEditingController interestRateController = TextEditingController();
  final TextEditingController lvrOtherController = TextEditingController();

  // Calculation results
  double? stampDuty;
  double? initialContribution;
  double? monthlyMortgage;
  double? totalInitialContribution;

  // Button logic
  bool _skipped = false;
  bool _calculated = false;

  // -----------------------------
  // NEW: Reactivate Calculate when user edits anything
  // -----------------------------
  void _checkFormFilled() {
    setState(() {
      if (_skipped) {
        _skipped = false;
        _calculated = false;
      }
    });
  }

  // Get LVR numeric value
  double _getLvrValue() {
    if (lvrValue == null) return 0;
    if (lvrValue == "Other") {
      return double.tryParse(lvrOtherController.text.trim()) ?? 0;
    }
    return double.parse(lvrValue!.replaceAll("%", ""));
  }

  // Perform real calculation
  void _performCalculation() {
    if (!_formKey.currentState!.validate()) return;

    final propertyValue =
        double.tryParse(propertyValueController.text.trim()) ?? 0;
    final lvrPercent = _getLvrValue();
    final interestRate =
        double.tryParse(interestRateController.text.trim()) ?? 0;

    final sd = calculateStampDuty(
      state: stateValue!,
      propertyValue: propertyValue,
    );

    final ic = propertyValue - (propertyValue * lvrPercent / 100);

    final mm = calculateMonthlyMortgage(
      propertyValue: propertyValue,
      lvrPercent: lvrPercent,
      annualInterestPercent: interestRate,
    );

    final total = sd + ic + 2000;

    setState(() {
      stampDuty = sd;
      initialContribution = ic;
      monthlyMortgage = mm;
      totalInitialContribution = total;

      _calculated = true;
      _skipped = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Know Your Finances"),
        backgroundColor: Colors.black,
        foregroundColor: Color(0xFFFFD700),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [

                // PROPERTY TYPE
                const Text("Property Type *",
                    style: TextStyle(fontWeight: FontWeight.bold)),
                const SizedBox(height: 6),
                DropdownButtonFormField<String>(
                  value: propertyType,
                  decoration: const InputDecoration(border: OutlineInputBorder()),
                  items: ["House", "Apartment", "Townhouse", "Land", "Retirement"]
                      .map((e) => DropdownMenuItem(value: e, child: Text(e)))
                      .toList(),
                  validator: (v) => v == null ? "Required" : null,
                  onChanged: (value) {
                    setState(() => propertyType = value);
                    _checkFormFilled();
                  },
                ),
                const SizedBox(height: 16),

                // STATE
                const Text("State *",
                    style: TextStyle(fontWeight: FontWeight.bold)),
                const SizedBox(height: 6),
                DropdownButtonFormField<String>(
                  value: stateValue,
                  decoration: const InputDecoration(border: OutlineInputBorder()),
                  items: ["NSW", "VIC", "QLD", "SA", "WA", "TAS", "ACT", "NT"]
                      .map((e) => DropdownMenuItem(value: e, child: Text(e)))
                      .toList(),
                  validator: (v) => v == null ? "Required" : null,
                  onChanged: (value) {
                    setState(() => stateValue = value);
                    _checkFormFilled();
                  },
                ),
                const SizedBox(height: 16),

                // PROPERTY VALUE
                const Text("Estimated Property Value *",
                    style: TextStyle(fontWeight: FontWeight.bold)),
                const SizedBox(height: 6),
                TextFormField(
                  controller: propertyValueController,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(
                    border: OutlineInputBorder(),
                    hintText: "Enter amount (max 10,000,000)",
                  ),
                  validator: (value) {
                    if (value == null || value.trim().isEmpty) {
                      return "Required";
                    }
                    final v = double.tryParse(value.trim());
                    if (v == null) return "Numeric only";
                    if (v <= 0) return "Must be > 0";
                    if (v > 10000000) return "Max allowed is 10,000,000";
                    return null;
                  },
                  onChanged: (_) => _checkFormFilled(),
                ),
                const SizedBox(height: 16),

                // LVR
                const Text("LVR % *",
                    style: TextStyle(fontWeight: FontWeight.bold)),
                const SizedBox(height: 6),
                DropdownButtonFormField<String>(
                  value: lvrValue,
                  decoration: const InputDecoration(border: OutlineInputBorder()),
                  items: ["70%", "80%", "90%", "95%", "Other"]
                      .map((e) => DropdownMenuItem(value: e, child: Text(e)))
                      .toList(),
                  validator: (v) => v == null ? "Required" : null,
                  onChanged: (value) {
                    setState(() => lvrValue = value);
                    _checkFormFilled();
                  },
                ),

                if (lvrValue == "Other") ...[
                  const SizedBox(height: 8),
                  TextFormField(
                    controller: lvrOtherController,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(
                      border: OutlineInputBorder(),
                      hintText: "Enter LVR% (0–100)",
                    ),
                    validator: (value) {
                      if (lvrValue != "Other") return null;
                      if (value == null || value.trim().isEmpty) {
                        return "Required";
                      }
                      final v = double.tryParse(value.trim());
                      if (v == null) return "Numeric only";
                      if (v < 0 || v > 100) return "Must be 0–100";
                      return null;
                    },
                    onChanged: (_) => _checkFormFilled(),
                  ),
                ],

                const SizedBox(height: 16),

                // INTEREST RATE
                const Text("Home Loan Interest Rate % *",
                    style: TextStyle(fontWeight: FontWeight.bold)),
                const SizedBox(height: 6),
                TextFormField(
                  controller: interestRateController,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(
                    border: OutlineInputBorder(),
                    hintText: "Enter % rate",
                  ),
                  validator: (value) {
                    if (value == null || value.trim().isEmpty) {
                      return "Required";
                    }
                    final v = double.tryParse(value.trim());
                    if (v == null) return "Numeric only";
                    if (v < 0 || v > 100) return "Must be 0–100";
                    return null;
                  },
                  onChanged: (_) => _checkFormFilled(),
                ),

                const SizedBox(height: 30),

                // CALCULATE BUTTON
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: _skipped ? null : _performCalculation,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.black,
                      foregroundColor: const Color(0xFFFFD700),
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                        side: BorderSide(
                          color: !_skipped
                              ? const Color(0xFFFFD700)
                              : Colors.grey,
                          width: 1.5,
                        ),
                      ),
                    ),
                    child: const Text(
                      "Calculate",
                      style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                    ),
                  ),
                ),

                const SizedBox(height: 12),

                // SKIP BUTTON
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: () {
                      setState(() {
                        _skipped = true;
                        _calculated = false;
                      });
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.black,
                      foregroundColor: const Color(0xFFFFD700),
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                        side: const BorderSide(
                          color: Color(0xFFFFD700),
                          width: 1.5,
                        ),
                      ),
                    ),
                    child: const Text(
                      "Skip for now",
                      style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                    ),
                  ),
                ),

                const SizedBox(height: 20),

                // RESULTS SECTION
                if (_calculated) ...[
                  Text(
                    "Estimated Stamp Duty: \$${stampDuty!.toStringAsFixed(2)}",
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 8),
                  Text("Initial Contribution: \$${initialContribution!.toStringAsFixed(2)}"),
                  const SizedBox(height: 8),
                  Text("Monthly Mortgage: \$${monthlyMortgage!.toStringAsFixed(2)}"),
                  const SizedBox(height: 8),
                  Text("Total Initial Contribution: \$${totalInitialContribution!.toStringAsFixed(2)}"),
                  const SizedBox(height: 24),
                ],

                // BUY YOUR DREAM HOME BUTTON
                if (_calculated || _skipped)
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.pushNamed(context, '/investorTerms');
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.black,
                        foregroundColor: const Color(0xFFFFD700),
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                          side: const BorderSide(
                            color: Color(0xFFFFD700),
                            width: 1.5,
                          ),
                        ),
                      ),
                      child: const Text(
                        "Buy Your Dream Home",
                        style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
