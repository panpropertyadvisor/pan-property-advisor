import 'package:flutter/material.dart';
import 'buyers_agent_preview_page.dart';

class BuyersAgentDetailsPage extends StatefulWidget {
  const BuyersAgentDetailsPage({super.key});

  @override
  State<BuyersAgentDetailsPage> createState() =>
      _BuyersAgentDetailsPageState();
}

class _BuyersAgentDetailsPageState extends State<BuyersAgentDetailsPage> {
  bool _showSection2 = false;
  bool _showSection3 = false;

  String _errorMessage = "";

  final _fullNameController = TextEditingController();
  final _titleController = TextEditingController();
  final _companyNameController = TextEditingController();
  final _experienceController = TextEditingController();

  final _licenceController = TextEditingController();
  final _afcaController = TextEditingController();

  final _shortBioController = TextEditingController();
  final _fullBioController = TextEditingController();
  final _differenceController = TextEditingController();
  final _awardsController = TextEditingController();
  final _testimonialsController = TextEditingController();

  final _emailController = TextEditingController();
  final _mobileController = TextEditingController();
  final _availabilityController = TextEditingController();

  final _officeAddressController = TextEditingController();
  final _serviceAreasController = TextEditingController();

  final _linkedinController = TextEditingController();
  final _googleReviewsController = TextEditingController();
  final _websiteController = TextEditingController();

  String? _selectedSpecialisation;
  final List<String> _selectedStates = [];
  bool _onlineAppointments = false;

  bool _validateSection1() {
    return _fullNameController.text.trim().isNotEmpty &&
        _companyNameController.text.trim().isNotEmpty &&
        _experienceController.text.trim().isNotEmpty;
  }

  bool _validateSection2() {
    return _licenceController.text.trim().isNotEmpty &&
        _afcaController.text.trim().isNotEmpty &&
        _selectedSpecialisation != null &&
        _selectedStates.isNotEmpty;
  }

  bool _validateAll() {
    return _validateSection1() &&
        _validateSection2() &&
        _shortBioController.text.trim().isNotEmpty &&
        _emailController.text.trim().isNotEmpty &&
        _mobileController.text.trim().isNotEmpty;
  }

  void _attemptSave() {
    if (!_validateAll()) {
      setState(() {
        _errorMessage = "Please complete mandatory fields";
      });
      return;
    }

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => BuyersAgentPreviewPage(
          fullName: _fullNameController.text,
          title: _titleController.text,
          companyName: _companyNameController.text,
          experience: _experienceController.text,
          shortBio: _shortBioController.text,
          fullBio: _fullBioController.text,
          difference: _differenceController.text,
          awards: _awardsController.text,
          testimonials: _testimonialsController.text,
          email: _emailController.text,
          mobile: _mobileController.text,
          officeAddress: _officeAddressController.text,
          serviceAreas: _serviceAreasController.text,
          linkedin: _linkedinController.text,
          googleReviews: _googleReviewsController.text,
          website: _websiteController.text,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (_validateSection1()) _showSection2 = true;
    if (_validateSection2()) _showSection3 = true;

    return Scaffold(
      appBar: AppBar(title: const Text("Buyers Agent Details")),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              if (_errorMessage.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: Text(
                    _errorMessage,
                    style: const TextStyle(color: Colors.red, fontSize: 16),
                  ),
                ),

              sectionTitle("1. Personal & Professional Identity"),

              buildMandatoryField("Full Name *", _fullNameController),
              buildTextField("Professional Title", _titleController, 50),
              buildMandatoryField("Company Name *", _companyNameController),
              buildMandatoryNumber(
                  "Years of Experience *", _experienceController),

              imageUploadPlaceholder("Profile Photo"),
              imageUploadPlaceholder("Company Logo"),

              if (_showSection2) ...[
                const SizedBox(height: 24),
                sectionTitle("2. Licensing & Focus Areas"),

                buildMandatoryField(
                    "Buyers Agent Licence Number *", _licenceController),
                buildMandatoryField(
                    "AFCA Membership Number *", _afcaController),

                dropdownField(
                  "Primary Specialisation *",
                  [
                    "First Home Buyers",
                    "Investors",
                    "Upsizers/Downsizers",
                    "Commercial Property",
                    "Other"
                  ],
                  _selectedSpecialisation,
                  (value) => setState(() => _selectedSpecialisation = value),
                ),

                multiSelectStates(),
              ],

              if (_showSection3) ...[
                const SizedBox(height: 24),
                sectionTitle("3. About / Bio"),

                buildMandatoryField("Short Bio *", _shortBioController),
                buildLongField("Full Bio / Story", _fullBioController, 2000),
                buildLongField("What Makes You Different?",
                    _differenceController, 1000),
                buildLongField("Awards & Recognition", _awardsController, 1000),
                buildLongField("Customer Testimonials",
                    _testimonialsController, 2000),

                const SizedBox(height: 24),
                sectionTitle("8. Contact & Availability"),

                buildMandatoryField("Email Address *", _emailController),
                buildMandatoryNumber("Mobile Number *", _mobileController),
                buildTextField(
                    "Availability Hours", _availabilityController, 100),

                SwitchListTile(
                  title: const Text("Online Appointments Available"),
                  value: _onlineAppointments,
                  onChanged: (v) {
                    setState(() => _onlineAppointments = v);
                  },
                ),

                const SizedBox(height: 40),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: _attemptSave,
                    child: const Text("Save & Preview"),
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }

  Widget sectionTitle(String title) => Padding(
        padding: const EdgeInsets.only(bottom: 12),
        child: Text(
          title,
          style: const TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
      );

  Widget buildMandatoryField(
      String label, TextEditingController controller) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: TextField(
        controller: controller,
        decoration: InputDecoration(
          labelText: label,
          border: const OutlineInputBorder(),
          errorText:
              controller.text.trim().isEmpty ? "Required" : null,
        ),
      ),
    );
  }

  Widget buildMandatoryNumber(
      String label, TextEditingController controller) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: TextField(
        controller: controller,
        keyboardType: TextInputType.number,
        decoration: InputDecoration(
          labelText: label,
          border: const OutlineInputBorder(),
          errorText:
              controller.text.trim().isEmpty ? "Required" : null,
        ),
      ),
    );
  }

  Widget buildTextField(
      String label, TextEditingController controller, int max) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: TextField(
        controller: controller,
        maxLength: max,
        decoration: InputDecoration(
          labelText: label,
          border: const OutlineInputBorder(),
        ),
      ),
    );
  }

  Widget buildLongField(
      String label, TextEditingController controller, int max) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: TextField(
        controller: controller,
        maxLength: max,
        maxLines: 5,
        decoration: InputDecoration(
          labelText: label,
          border: const OutlineInputBorder(),
        ),
      ),
    );
  }

  Widget dropdownField(String label, List<String> items,
      String? selected, Function(String?) onChanged) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: DropdownButtonFormField<String>(
        value: selected,
        decoration: InputDecoration(
          labelText: label,
          border: const OutlineInputBorder(),
        ),
        items: items
            .map((e) => DropdownMenuItem(
                  value: e,
                  child: Text(e),
                ))
            .toList(),
        onChanged: onChanged,
      ),
    );
  }

  Widget multiSelectStates() {
    final states = ["NSW", "VIC", "QLD", "SA", "WA", "TAS", "ACT", "NT"];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text("States You Operate In *",
            style: TextStyle(fontWeight: FontWeight.bold)),
        ...states.map((state) {
          return CheckboxListTile(
            title: Text(state),
            value: _selectedStates.contains(state),
            onChanged: (v) {
              setState(() {
                if (v == true) {
                  _selectedStates.add(state);
                } else {
                  _selectedStates.remove(state);
                }
              });
            },
          );
        }),
      ],
    );
  }

  Widget imageUploadPlaceholder(String label) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label),
          const SizedBox(height: 8),
          Container(
            height: 120,
            width: double.infinity,
            decoration: BoxDecoration(
              border: Border.all(color: Colors.grey),
            ),
            child: const Center(
              child: Text("Upload Image"),
            ),
          ),
        ],
      ),
    );
  }
}
