import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'firebase_options.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter_stripe/flutter_stripe.dart';


// General Pages
import 'pages/home_page.dart';
import 'pages/welcome_page.dart';
import 'pages/about_you_page.dart';
import 'pages/know_your_finances_page.dart';
import 'pages/coming_soon_page.dart';
import 'pages/investor_about_you_page.dart';
import 'pages/investor_terms_page.dart';

// Mortgage Broker Pages
import 'pages/mortgage_broker_intro_page.dart';
import 'pages/mortgage_broker_about_you_page.dart';
import 'pages/mortgage_broker_details_page.dart';
import 'pages/mortgage_broker_preview_page.dart';

// Buyers Agent Pages
import 'pages/buyers_agent_intro_page.dart';
import 'pages/buyers_agent_about_you_page.dart';
import 'pages/buyers_agent_details_page.dart';
import 'pages/buyers_agent_preview_page.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // ⭐ Initialize Stripe BEFORE Firebase
  Stripe.publishableKey = "pk_test_51TiCgaHFW23OY0ENEcTGlxKdb8tJ5E569Dh5VVooDl4Pnc5aP1j1pjOzOjQvOeJU6lzvE6Cg32ayNi4N7fnemPWq00J18dgtAw";
                          
  await Stripe.instance.applySettings();

  // ⭐ Initialize Firebase
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );

  runApp(const PanPropertyAdvisorApp());
}


class PanPropertyAdvisorApp extends StatelessWidget {
  const PanPropertyAdvisorApp({super.key});

  Future<bool> _checkLogin() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool('isLoggedIn') ?? false;
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'PAN Property Advisor',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.indigo,
        useMaterial3: true,
      ),

      home: FutureBuilder<bool>(
        future: _checkLogin(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Scaffold(
              body: Center(child: CircularProgressIndicator()),
            );
          }
          return snapshot.data == true ? const HomePage() : WelcomePage();
        },
      ),

      routes: {
        // General
        '/aboutYou': (_) => AboutYouPage(),
        '/knowYourFinances': (_) => KnowYourFinancePage(),
        '/comingSoon': (_) => ComingSoonPage(),
        '/investorAboutYou': (_) => InvestorAboutYouPage(),
        '/investorTerms': (_) => InvestorTermsPage(),

        // Mortgage Broker
        '/mortgageBrokerIntro': (_) => MortgageBrokerIntroPage(),
        '/mortgageBrokerAboutYou': (_) => MortgageBrokerAboutYouPage(),
        '/mortgageBrokerDetails': (_) => MortgageBrokerDetailsPage(),

        // Buyers Agent
        '/buyersAgentIntro': (_) => BuyersAgentIntroPage(),
        '/buyersAgentAboutYou': (_) => BuyersAgentAboutYouPage(),
        '/buyersAgentDetails': (_) => BuyersAgentDetailsPage(),
      },

      // Preview routes with arguments
      onGenerateRoute: (settings) {
        if (settings.name == '/mortgageBrokerPreview') {
          final args = settings.arguments as Map<String, dynamic>;
          return MaterialPageRoute(
            builder: (_) => MortgageBrokerPreviewPage(
              fullName: args['fullName'],
              title: args['title'],
              companyName: args['companyName'],
              experience: args['experience'],
              shortBio: args['shortBio'],
              fullBio: args['fullBio'],
              difference: args['difference'],
              awards: args['awards'],
              testimonials: args['testimonials'],
              email: args['email'],
              mobile: args['mobile'],
              officeAddress: args['officeAddress'],
              serviceAreas: args['serviceAreas'],
              linkedin: args['linkedin'],
              googleReviews: args['googleReviews'],
              website: args['website'],
            ),
          );
        }

        if (settings.name == '/buyersAgentPreview') {
          final args = settings.arguments as Map<String, dynamic>;
          return MaterialPageRoute(
            builder: (_) => BuyersAgentPreviewPage(
              fullName: args['fullName'],
              title: args['title'],
              companyName: args['companyName'],
              experience: args['experience'],
              shortBio: args['shortBio'],
              fullBio: args['fullBio'],
              difference: args['difference'],
              awards: args['awards'],
              testimonials: args['testimonials'],
              email: args['email'],
              mobile: args['mobile'],
              officeAddress: args['officeAddress'],
              serviceAreas: args['serviceAreas'],
              linkedin: args['linkedin'],
              googleReviews: args['googleReviews'],
              website: args['website'],
            ),
          );
        }

        return null;
      },
    );
  }
}
